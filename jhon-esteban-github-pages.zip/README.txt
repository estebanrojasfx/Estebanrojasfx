# Landing de Jhon Esteban — Trader & Mentor

## Publicar en GitHub Pages

1. Ve a [github.com](https://github.com) y crea un nuevo repositorio (ej: `landing-trader`).
2. Sube el archivo `index.html` de esta carpeta.
3. En el repo, entra a **Settings > Pages**.
4. En “Source” selecciona la rama `main` y carpeta `/root`.
5. Guarda. Espera 1-2 minutos.
6. Tu web estará en: `https://TU-USUARIO.github.io/landing-trader`

¡Listo! Gratis y público.
